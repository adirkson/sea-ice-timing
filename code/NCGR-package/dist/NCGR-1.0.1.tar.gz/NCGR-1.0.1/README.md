# NCGR

A python package for calibrating probabilistic forecasts of sea-ice retreat and advance
dates using non-homogeneous Gaussian regression (NCGR). Documentation and examples on usage
can be found at <https://adirkson.github.io/sea-ice-timing/>.

